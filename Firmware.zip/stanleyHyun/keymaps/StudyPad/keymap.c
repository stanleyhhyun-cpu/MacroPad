#include QMK_KEYBOARD_H

// Custom keycodes
enum custom_keycodes {
    TIMER_25 = SAFE_RANGE,
    TIMER_5,
    TOGGLE_PWR
};

bool power_on = true;

// Timer variables
uint32_t timer_start = 0;
bool timer_running = false;
uint32_t timer_duration = 0;
uint8_t timer_type = 0; // 1 = 25min, 2 = 5min

// Keymap
const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
    [0] = LAYOUT(
        TIMER_25, TIMER_5, TOGGLE_PWR
    )
};

// WINDOWS TIMER FUNCTION
void open_timer(const char* duration) {
    tap_code(KC_LGUI);        // Open Start Menu
    wait_ms(400);

    tap_code(KC_ESC);         // Clear anything
    wait_ms(100);

    SEND_STRING(duration);
    SEND_STRING(" minute timer");

    wait_ms(150);
    tap_code(KC_ENTER);
}

// KEY HANDLER
bool process_record_user(uint16_t keycode, keyrecord_t *record) {
    if (record->event.pressed) {
        switch (keycode) {

            case TIMER_25:
                if (power_on) {
                    open_timer("25");
                    rgblight_setrgb(0, 255, 0); // Green

                    timer_start = timer_read();
                    timer_duration = 1500000; // 25 min
                    timer_running = true;
                    timer_type = 1;
                }
                return false;

            case TIMER_5:
                if (power_on) {
                    open_timer("5");
                    rgblight_setrgb(255, 255, 0); // Yellow

                    timer_start = timer_read();
                    timer_duration = 300000; // 5 min
                    timer_running = true;
                    timer_type = 2;
                }
                return false;

            case TOGGLE_PWR:
                power_on = !power_on;
                timer_running = false;

                if (power_on) {
                    rgblight_setrgb(0, 0, 255); // Blue
                } else {
                    rgblight_setrgb(255, 0, 0); // Red
                }
                return false;
        }
    }
    return true;
}

// TIMER FINISH FLASH EFFECT
void matrix_scan_user(void) {
    if (timer_running && timer_elapsed(timer_start) > timer_duration) {
        timer_running = false;

        for (int i = 0; i < 6; i++) {
            if (timer_type == 1) {
                rgblight_setrgb(0, 255, 0); // Green
            } else if (timer_type == 2) {
                rgblight_setrgb(255, 255, 0); // Yellow
            }

            wait_ms(300);
            rgblight_setrgb(0, 0, 0); // Off
            wait_ms(300);
        }
    }
}
